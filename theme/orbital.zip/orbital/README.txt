=== Orbital ===
Contributors: Mi taladro
Requires at least: WordPress 4.7
Version: 1.0
Tags: one-column, two-columns, right-sidebar, flexible-header, accessibility-ready, custom-colors, custom-header, custom-menu, custom-logo, editor-style, featured-images, footer-widgets, post-formats, rtl-language-support, sticky-post, theme-options, threaded-comments, translation-ready

== Description ==

== Installation ==

== Copyright ==

Theme Name: Orbital
Theme URI: https://romualdfons.com/mejor-tema-wordpress-seo/
Author: Pau Casanellas
Author URI: http://romualdfons.com/
Description: Proudly coded by Pau Casanellas, member of Mi taladro perforará el cielo S.L
Version: 1.0
License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Text Domain: orbital
Tags: one-column, two-columns, right-sidebar, flexible-header, accessibility-ready, custom-colors, custom-header, custom-menu, custom-logo, editor-style, featured-images, footer-widgets, post-formats, rtl-language-support, sticky-post, theme-options, threaded-comments, translation-ready
