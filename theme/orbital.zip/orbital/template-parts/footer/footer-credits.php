<div class="credits row">

	<?php if(get_bloginfo('description')) : ?>

		<p><?php bloginfo('description'); ?></p>

	<?php else : ?>

		<p><?php bloginfo('name'); ?></p>

	<?php endif; ?>
	
</div>
